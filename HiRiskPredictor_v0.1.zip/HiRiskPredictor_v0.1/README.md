# HiRiskPredictor


## Introduction

HiRiskPredictor is a tool for detecting high-risk variants of SARS-CoV-2.

## Dependence

HiRiskPredictor can be run on most Linux systems. You need install Python 3.8.16, and install modules listed in requirements.txt.

## Options

### Haplotype network construction and feature extraction
```
Usage: python main.py --calc_features [option] ...

Options:
  --samples <file>           input strains file (standard_dataset_before_20220228.tsv.tar.gz in https://zenodo.org/records/10056873, need uzip)
  --alias <file>             input alias file (data/alias_key.json)
  --wholabels <file>         input WHO label file (data/WHOLabels.tsv)
  --output <dir>             directory for output
  --interval_days <int>      interval days for surveilance (7)
  --start_date <yyyy-mm-dd>  the start date for surveilance (2020-10-09)
  --end_date <yyyy-mm-dd>    the end date for surveilance (2020-12-11)
  --nprocesses <int>         the number of processes (7)
```

### Prediction of high-risk variants at a series of time points

```
Usage: python main.py --predict_surveillance [option] ...

  --alias <file>                input alias file (data/alias_key.json)
  --wholabels <file>            input WHO label file (data/WHOLabels.tsv)
  --output <dir>                directory for output. It also need to contain features calculated in previous step
  --interval_days <int>         interval days for surveilance (7)
  --start_date <yyyy-mm-dd>     the start date for surveilance (2020-10-09)
  --end_date <yyyy-mm-dd>       the end date for surveilance (2020-12-11)
  --selected_feature_ml <file>  the file recorded the selected features and machine learning model (data/selected.pkl)
```

### Performance evaluation

```
Usage: python main.py --performance_surveillance [option] ...

  --alias <file>                input alias file (data/alias_key.json)
  --wholabels <file>            input WHO label file (data/WHOLabels.tsv)
  --output <dir>                directory for output. It also need to contain files calculated in previous two steps
  --interval_days <int>         interval days for surveilance (7)
  --start_date <yyyy-mm-dd>     the start date for surveilance (2020-10-09)
  --end_date <yyyy-mm-dd>       the end date for surveilance (2020-12-11)
  --selected_feature_ml <file>  the file recorded the selected features and machine learning model (data/selected.pkl)
```

## Contributors
- HiRiskPredictor contributors

## Citation

Please cite this for HiRiskPredictor:
```
Lun Li, Cuiping Li, Na Li, Dong Zou, Wenming Zhao, Yongbiao Xue, Zhang Zhang, Yiming Bao, Shuhui Song. Machine learning detection of SARS-CoV-2 high-risk variants. bioRxiv. 2023.04.19.537460. doi: https://doi.org/10.1101/2023.04.19.537460
```
or BibTeX Format:
```
@article {Li2023.04.19.537460,
	author = {Lun Li and Cuiping Li and Na Li and Dong Zou and Wenming Zhao and Yongbiao Xue and Zhang Zhang and Yiming Bao and Shuhui Song},
	title = {Machine learning detection of SARS-CoV-2 high-risk variants},
	elocation-id = {2023.04.19.537460},
	year = {2023},
	doi = {10.1101/2023.04.19.537460},
	publisher = {Cold Spring Harbor Laboratory},
	URL = {https://www.biorxiv.org/content/early/2023/04/20/2023.04.19.537460},
	eprint = {https://www.biorxiv.org/content/early/2023/04/20/2023.04.19.537460.full.pdf},
	journal = {bioRxiv}
}
```

Please cite this for 2019 Novel Coronavirus Resource:
```
Zhao WM, Song SH, Chen ML, et al. The 2019 novel coronavirus resource. Yi Chuan. 2020;42(2):212–221. doi:10.16288/j.yczz.20-030 [PMID: 32102777]
```
or BibTeX Format:
```
@article{zhao20202019,
  title={The 2019 novel coronavirus resource.},
  author={Zhao, Wen-Ming and Song, Shu-Hui and Chen, Mei-Li and Zou, Dong and Ma, Li-Na and Ma, Ying-Ke and Li, Ru-Jiao and Hao, Li-Li and Li, Cui-Ping and Tian, Dong-Mei and others},
  journal={Yi chuan= Hereditas},
  volume={42},
  number={2},
  pages={212--221},
  year={2020}
}
```

## Contact
If you have any questions, feel free to contact us. lil@big.ac.cn

## License
MIT License
>  Copyright (c) 2023 HiRiskPredictor contributors
>
>  Permission is hereby granted, free of charge, to any person obtaining a copy
>  of this software and associated documentation files (the "Software"), to deal
>  in the Software without restriction, including without limitation the rights
>  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
>  copies of the Software, and to permit persons to whom the Software is
>  furnished to do so, subject to the following conditions:
>
>  The above copyright notice and this permission notice shall be included in
>  all copies or substantial portions of the Software.
>
>  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
>  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
>  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
>  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
>  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
>  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
>  THE SOFTWARE.
>
