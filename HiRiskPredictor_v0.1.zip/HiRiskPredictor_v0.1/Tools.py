import time
import pandas as pd
import re
import datetime as dt
import json
import numpy as np


def file_line(file_name: str):
    with open(file_name) as f:
        for count, _ in enumerate(f, 1):
            pass
    return count


class TicToc:
    def __init__(self):
        self.t1 = 0
        self.t2 = 0

    def tic(self):
        self.t1 = time.time()

    def toc(self):
        self.t2 = time.time()
        return self.t2 - self.t1


def nan2void_str(tt):
    if pd.isna(tt):
        return ''
    return tt


def str2date(tt):
    return str2date_new(tt)


def str2date_old(tt):
    # only work for dates after 1970
    return pd.to_datetime(tt, format="%Y-%m-%d").date()


def str2date_new(tt: str):
    date_pat = re.compile(r'\A([0-9]{1,4})-([0-9]{1,2})-([0-9]{1,2})\Z')
    matched = date_pat.match(tt)
    return dt.date(int(matched[1]),
                   int(matched[2]),
                   int(matched[3]))


def str2mut_list(str_mutations):
    if str_mutations == '':
        return set()
    if str_mutations is None:
        return set()
    if pd.isna(str_mutations):
        return set()
    return set(str_mutations.split(';'))


def str2pango(str_pango):
    # not match: None
    pat_pango = re.compile(r'\A[A-Z]+(\.[0-9]+)*\Z')
    if pat_pango.match(str_pango) is None:
        return None
    return str_pango


def str2pango_set(str_pango):
    if str_pango == '':
        return set()
    return set(str_pango.split(';'))


def read_samples(path: str, n_rows=None, new=False) -> pd.DataFrame:
    if new:
        return read_samples_detector_new(path, n_rows=n_rows)
    else:
        return read_samples_detector(path, n_rows=n_rows)


def read_samples_old(path: str, n_rows=None) -> pd.DataFrame:
    """
    read sample data
    :param path: path of samples
    :type path: str
    :param n_rows: number of rows needed to read
    :type n_rows: int or None
    :return: the samples
    """
    df = pd.read_csv(path, nrows=n_rows, sep='\t', header=None,
                     dtype={0: str, 2: str, 3: str, 5: str, 6: str},
                     converters={1: str2date, 4: str2pango},
                     names=['Acc', 'cDate', 'sDate_str', 'Country', 'Pango', 'WHOLabel', 'Mutations_str']
                     )
    df['sDate'] = df['sDate_str'].apply(str2date)
    date_ref = min(df['sDate'])
    df['sDate_int'] = df['sDate'].apply(lambda x: (x - date_ref).days)
    df['Mutations_str'] = df['Mutations_str'].apply(nan2void_str)
    df['Mutations'] = df['Mutations_str'].apply(str2mut_list)
    return df


def read_samples_mcan(path: str, n_rows=None) -> pd.DataFrame:
    """
    read sample data for construct haplotype network
    only need Acc, sDate, and Mutations; only str type; trans None to '' for Mutations
    :param path: path of samples
    :type path: str
    :param n_rows: number of rows needed to read
    :type n_rows: int or None
    :return: the samples
    """
    df = pd.read_csv(path, nrows=n_rows, sep='\t', header=None,
                     dtype={0: str, 2: str, 6: str},
                     names=['Acc', 'sDate_str', 'Mutations_str'],
                     usecols=[0, 2, 6]
                     )
    df['Mutations_str'] = df['Mutations_str'].apply(nan2void_str)
    return df


def read_samples_detector(path: str, n_rows=None) -> pd.DataFrame:
    """
    read sample data
    :param path: path of samples
    :type path: str
    :param n_rows: number of rows needed to read
    :type n_rows: int or None
    :return: the samples
    """
    df = pd.read_csv(path, nrows=n_rows, sep='\t', header=None,
                     dtype={0: str, 2: str, 3: str, 5: str, 6: str},
                     converters={4: str2pango},
                     names=['Acc', 'sDate_str', 'Country', 'Pango', 'WHOLabel', 'Mutations_str']
                     )
    df['sDate'] = df['sDate_str'].apply(str2date)
    df['Mutations_str'] = df['Mutations_str'].apply(nan2void_str)
    return df


def read_samples_detector_new(path: str, n_rows=None) -> pd.DataFrame:
    """
    read from file generated from python version
    read sample data
    :param path: path of samples
    :type path: str
    :param n_rows: number of rows needed to read
    :type n_rows: int or None
    :return: the samples
    """
    df = pd.read_csv(path, nrows=n_rows, sep='\t', header=0,
                     names=['Acc', 'Pango', 'Country', 'sDate_str', 'Mutations_str'],
                     dtype={'Acc': str, 'Country': str, 'sDate_str': str, 'Mutations_str': str},
                     converters={'Pango': str2pango},
                     usecols=['Acc', 'Pango', 'Country', 'sDate_str', 'Mutations_str'],
                     index_col='Acc'
                     )
    df['sDate'] = df['sDate_str'].apply(str2date)
    df['Mutations_str'] = df['Mutations_str'].apply(nan2void_str)
    return df


# PANGO
def read_alias(path):
    with open(path, 'r') as aliasFile:
        alias_json = aliasFile.read()
    dict_alias = json.loads(alias_json)
    return dict_alias


def pango_alias2real_name(dict_alias, str_alias):
    if type(str_alias) != str:
        return None
    if re.match(r'\A([A-Z]+)(\.[0-9]+)*\Z', str_alias) is None:
        print("wrong mutation format")
        return None
    letters = re.match(r'\A([A-Z]+)', str_alias).group()
    if letters in dict_alias:
        value = dict_alias[letters]
        if type(value) == str:
            if value != '':
                return value + re.search(r'(\.[0-9]+)*\Z', str_alias).group()
    return str_alias


def pango_alias2real_name_for_set(set_alias, dict_alias):
    # 变成apply??
    set_real_name = set()
    for pango_alias in set_alias:
        real_name = pango_alias2real_name(dict_alias, pango_alias)
        if real_name is not None:
            set_real_name.add(real_name)
    return set_real_name


def read_who_labels(path, dict_alias):
    df_who_labels = pd.read_csv(path, sep='\t', header=0,
                                dtype={'WHOLabel': str, 'WHORisk': str},
                                converters={'DesignDateAsVOCVOI': str2date, 'Pango': str2pango_set}
                                )
    if dict_alias is not None:
        df_who_labels['PangoRealNameSets'] = \
            df_who_labels['Pango'].apply(lambda x: pango_alias2real_name_for_set(x, dict_alias))
    return df_who_labels


def pango2who_label(str_alias, dict_alias, df_who_labels, sublineage=True, ignore_recombination=False):
    if sublineage:
        return pango2who_label_sublineage(str_alias, dict_alias, df_who_labels,
                                          ignore_recombination=ignore_recombination)
    else:
        return pango2who_label_exact_lineage(str_alias, dict_alias, df_who_labels)


def pango2who_label_sublineage(str_alias, dict_alias, df_who_labels, ignore_recombination=False):
    real_name = pango_alias2real_name(dict_alias, str_alias)  # checked, good for BA*
    if real_name is None:
        return None
    if ignore_recombination:
        if real_name.startswith('X'):
            return None
    for var in df_who_labels.index:
        for pango_in_df_who in df_who_labels.loc[var, 'PangoRealNameSets']:
            if real_name.startswith(pango_in_df_who):
                if len(pango_in_df_who) == len(real_name):
                    return df_who_labels.loc[var, 'WHOLabel']
                elif real_name[len(pango_in_df_who)] == '.':
                    return df_who_labels.loc[var, 'WHOLabel']
    if ignore_recombination:
        return 'Others'
    else:
        return None


def pango2who_label_exact_lineage(str_alias, dict_alias, df_who_labels):
    real_name = pango_alias2real_name(dict_alias, str_alias)  # checked, good for BA*
    if real_name is None:
        return None
    for var in df_who_labels.index:
        for pango_in_df_who in df_who_labels.loc[var, 'PangoRealNameSets']:
            if real_name == pango_in_df_who:
                return df_who_labels.loc[var, 'WHOLabel']
    return None


def min_time(t1, t2):
    if pd.isna(t1):
        return t2
    elif pd.isna(t2):
        return t1
    else:
        return min(t1, t2)
