# memory!!!!
import igraph as ig
import matplotlib.pyplot as plt
import Tools
from typing import Set, List
from multiprocessing import Pool, set_start_method
import pandas as pd

global_mut_lst = None

class McAN:
    def __init__(self):
        self.samples = None
        self.samples_grouped = None
        self.df_haps = None
        self.graph = None

    # read
    def read_samples(self, path, n_rows=None):
        self.samples = Tools.read_samples_mcan(path, n_rows=n_rows)

    # McAN
    def find_haps(self):
        # time complexity O(n), n is the number of samples
        self.samples_grouped = self.samples.groupby('Mutations_str')
        #self.df_haps = self.samples_grouped.agg({'Acc': len,
        #                                         'sDate_str': min})
        #self.df_haps = self.df_haps.rename(columns={'Acc': 'size'})

        self.df_haps = self.samples_grouped.agg({'sDate_str': min})
        self.df_haps['size'] = self.samples_grouped.agg({'sDate_str': len})

        self.df_haps['Mutations'] = self.df_haps.index.to_series().apply(Tools.str2mut_list)
        self.df_haps['number_of_mutations'] = self.df_haps['Mutations'].apply(len)

    def sort_haps(self):
        # very fast, running time can be ignored
        self.df_haps = \
            self.df_haps.sort_values(axis=0,
                                     ascending=[False, False, True],
                                     by=['number_of_mutations', 'size', 'sDate_str'])

    def hap_index(self, int_hap_index):
        return self.df_haps.index[int_hap_index]

    @staticmethod
    def find_ancestor_single(location_start: int) -> int:
        global global_mut_lst
        i = location_start
        for j in range(i + 1, len(global_mut_lst)):
            if global_mut_lst[j].issubset(global_mut_lst[i]):
                return j

    def find_ancestor_single_process(self):
        global global_mut_lst
        global_mut_lst = self.df_haps['Mutations'].tolist()
        results = map(self.find_ancestor_single, [i for i in range(len(global_mut_lst) - 1)])
        global_mut_lst = None
        lst_anc = [i for i in results]
        lst_anc.append(None)
        self.df_haps['ancestor'] = lst_anc
        return results

    def find_ancestor_parallel(self, num_of_processes=1):
        # O(n^2), n is the number of haps.
        global global_mut_lst
        global_mut_lst = self.df_haps['Mutations'].tolist()
        with Pool(processes=num_of_processes) as pool:
            results = pool.map_async(self.find_ancestor_single, [i for i in range(len(global_mut_lst) - 1)])
            pool.close()
            pool.join()
        global_mut_lst = None
        lst_anc = list(map(lambda x: self.df_haps.index[x], results.get()))
        lst_anc.append(None)
        self.df_haps['ancestor'] = lst_anc
        return results

    @staticmethod
    def generate_mission_list(lst):
        for i in range(len(lst) - 1):
            yield (lst, i)

    def find_ancestor_parallel_new(self, num_of_processes=1):
        # O(n^2), n is the number of haps.
        set_start_method('spawn')
        lst = self.df_haps['Mutations'].tolist()
        chunk_size, extra = divmod(len(lst) - 1, num_of_processes * 2)
        if extra:
            chunk_size += 1
        with Pool(processes=num_of_processes) as pool:
            results = pool.starmap_async(
                self.find_ancestor_single,
                self.generate_mission_list(lst),
                chunksize=None)
            pool.close()
            pool.join()

        lst_anc = list(map(lambda x: self.df_haps.index[x], results.get()))
        lst_anc.append(None)
        self.df_haps['ancestor'] = lst_anc
        return results

    def mcan(self, num_of_processes=1):
        self.find_haps()
        self.sort_haps()
        self.find_ancestor_parallel(num_of_processes=num_of_processes)
        #self.find_ancestor_single_process()

    # visualization
    def make_graph(self):
        self.graph = ig.Graph(directed=True)
        vertices = []
        edges = []
        for hap_index in self.df_haps.index:
            vertices.append(hap_index)
            ancestor_index = self.df_haps.loc[hap_index, 'ancestor']
            if ancestor_index is not None:
                edges.append((ancestor_index, hap_index))
        self.graph.add_vertices(vertices)
        self.graph.add_edges(edges)

    def show_graph(self, type_show=None):
        fig, ax = plt.subplots(figsize=(5, 5))
        if type_show is None:
            ig.plot(self.graph, target=ax)
        else:
            ig.plot(self.graph,
                    target=ax,
                    vertex_size=[x ** 0.5 for x in self.graph.vs['size']]
                    )
        plt.show()

    # save and load the constructed haplotype network
    def save_haps(self, path: str) -> None:
        self.df_haps.to_pickle(path)

    def load_haps(self, path: str) -> None:
        self.df_haps = pd.read_pickle(path)


if __name__ == "__main__":
    tt = Tools.TicToc()
    path = "/home/lun/Study/HighRiskDetector/code/predict_general"
    path_samples_test = path + "/data/Acc_cDate_sDate_Country_Pango_WHOLabel_MutHiFreq"

    mcan = McAN()

    tt.tic()
    mcan.read_samples(path_samples_test, n_rows=100)
    print(f'read samples: {tt.toc()} seconds.')

    tt.tic()
    mcan.mcan(num_of_processes=1)
    print(f'all McAN: {tt.toc()} seconds.')

    tt.tic()
    mcan.make_graph()
    print(f'make_graph: {tt.toc()} seconds.')
    mcan.show_graph()

    #mcan.save_haps('/media/lun/Black_5TB_SG/code/predict_general/20230530/haps.pkl')

    #mcan2 = McAN()
    #mcan2.load_haps('/media/lun/Black_5TB_SG/code/predict_general/20230530/haps.pkl')
