import datetime as dt
import os
import pandas as pd
from scipy.stats import entropy
from sklearn.linear_model import LogisticRegression
import numpy as np
import math
import re
import joblib
import matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, roc_auc_score, average_precision_score, \
    accuracy_score, f1_score, precision_score, recall_score
from sklearn.ensemble import RandomForestClassifier

import Tools
import McAN
import lightgbm


def get_type_classifier():
    return ['lr', 'lgbm', 'rf']
    # return ['lr', 'lgbm', 'rf', 'svm']


def get_classifier(type_classifier):
    if type_classifier == 'lr':
        classifier = LogisticRegression(solver='lbfgs', class_weight='balanced', max_iter=1000, random_state=42)
    elif type_classifier == 'lgbm':
        classifier = lightgbm.LGBMClassifier(class_weight='balanced', random_state=42)
    elif type_classifier == 'rf':
        classifier = RandomForestClassifier(class_weight='balanced', random_state=42)
    # elif type_classifier == 'svm':
    #    classifier = SVC(class_weight='balanced', random_state=42, tol=0.001)
    else:
        classifier = None
    return classifier


def file_name_mcan(date):
    return f'McAN_{date}'


def file_name_features(date):
    return f'McAN_feature_{date}'


def file_name_y_score(date, type_classifier: str):
    return f'y_score_{type_classifier}_{date}'


def file_name_y_pred(date, type_classifier: str):
    return f'y_pred_{type_classifier}_{date}'


def file_name_pango(date):
    return f'pango_{date}'


def file_name_classifier(date: dt.date, type_classifier: str) -> str:
    return f'classifier_{type_classifier}_{date}'


def file_name_ground_truth(date: dt.date) -> str:
    return f'ground_truth_{date}'


class Features:
    def __init__(self, out_path=None, samples=None, current_date=None, time_interval=None):
        self.out_path = None
        self.samples = None
        self.current_date = None
        self.mcan = McAN.McAN()
        self.time_interval = None
        if out_path is not None:
            self.out_path = out_path
        if samples is not None:
            self.samples = samples
        if current_date is not None:
            self.current_date = current_date
        if time_interval is not None:
            self.time_interval = time_interval

    def read_samples(self, path, n_rows=None):
        self.samples = Tools.read_samples(path, n_rows=n_rows)

    def calc_network_features(self):
        # can be optimized by only calculate the
        self.mcan.graph.vs["betweenness"] = self.mcan.graph.betweenness(directed=True)
        self.mcan.graph.vs["out_degree"] = self.mcan.graph.degree(mode="out")
        self.mcan.graph.vs["depth"] = \
            list(map(
                lambda x: len(x) - 1,
                self.mcan.graph.get_shortest_paths(
                    '',
                    to=None,
                    mode="out",
                    output="vpath"
                )
            ))
        feature = self.mcan.graph.get_vertex_dataframe()
        feature.set_index(['name'], inplace=True)
        self.mcan.df_haps['betweenness'] = feature['betweenness']
        self.mcan.df_haps['out_degree'] = feature['out_degree']
        self.mcan.df_haps['depth'] = feature['depth']

    def calc_gie(self):
        def my_value_count(x):
            return x.value_counts().to_dict()

        self.mcan.df_haps['Country'] = self.mcan.samples_grouped.agg({'Country': my_value_count})
        self.mcan.df_haps['GIE'] = self.mcan.df_haps['Country'].apply(
            lambda x: entropy(np.array(list(x.values())) / np.sum(list(x.values())),
                              base=math.e)
        )

    def calc_ratio_of_new(self):
        self.mcan.df_haps['ratio_of_new'] = \
            self.mcan.samples_grouped['sDate'].apply(
                lambda x: sum(x > self.current_date - self.time_interval) / len(x))

    def calc_hap_pango(self):
        def df_pango2pang(x: pd.Series):
            rlt_value_counts = x.value_counts(dropna=False)
            if len(rlt_value_counts) <= 0:
                return None
            return rlt_value_counts.index[0]

        self.mcan.df_haps['Pango'] = \
            self.mcan.samples_grouped['Pango'].apply(
                df_pango2pang)

    def full_path(self):
        return f'{self.out_path}/{file_name_features(self.current_date)}.pkl'

    def save(self):
        self.mcan.save_haps(self.full_path())

    def load(self):
        self.mcan.__init__()
        self.mcan.load_haps(self.full_path())
        return self.mcan.df_haps

    def feature_pango_mcan(self, num_of_processes=1):
        self.mcan.__init__()
        self.mcan.samples = self.samples
        self.mcan.mcan(num_of_processes=num_of_processes)
        self.mcan.make_graph()
        self.calc_network_features()
        self.calc_gie()
        self.calc_ratio_of_new()
        self.calc_hap_pango()
        self.save()


class Label:
    def __init__(self):
        self.df_who_labels = None
        self.dict_alias = None
        self.series_labels = None

    def read_who_labels(self, path):
        self.df_who_labels = Tools.read_who_labels(path, self.dict_alias)

    def read_alias(self, path):
        self.dict_alias = Tools.read_alias(path)

    def pango_alias2real_name(self, str_alias):
        return Tools.pango_alias2real_name(self.dict_alias, str_alias)

    def assign_labels(self, series_pango, new_system=False):
        if not new_system:
            self.series_labels = series_pango.apply(
                lambda x: self.assign_labels_single_voc_voi_vs_others(x))
            return self.series_labels
        else:
            self.series_labels = series_pango.apply(
                lambda x: self.assign_labels_single_sub_lineage_free(x))
            return self.series_labels

    def assign_labels_single_voc_voi_vs_others(self, str_pango_alias):
        # maybe need to improve for recombination part
        df_who_labels_available = self.df_who_labels
        str_pango_real_name = self.pango_alias2real_name(str_pango_alias)
        # X 系列中,只有XB是0,其他全都是1
        if str_pango_real_name is None:
            return None
        if str_pango_real_name.startswith('XB'):
            if len(str_pango_real_name) == 2:
                return 'Low risk'
            elif str_pango_real_name.startswith('XB.'):
                return 'Low risk'
        if str_pango_real_name.startswith('X'):
            return 'VOC or VOI'
        # 非X系列的
        for var in df_who_labels_available.index:
            for pango_in_df_who in df_who_labels_available.loc[var, 'PangoRealNameSets']:
                if str_pango_real_name.startswith(pango_in_df_who):
                    if len(pango_in_df_who) == len(str_pango_real_name):
                        return 'VOC or VOI'
                    elif str_pango_real_name[len(pango_in_df_who)] == '.':
                        return 'VOC or VOI'
        return 'Low risk'

    # for who new system !!!
    def assign_labels_single_sub_lineage_free(self, str_pango_alias):
        df_who_labels_available = self.df_who_labels
        str_pango_real_name = self.pango_alias2real_name(str_pango_alias)
        if str_pango_real_name is None:
            return None
        if str_pango_real_name == '':
            return None
        if str_pango_real_name is np.nan:
            return None
        for var in df_who_labels_available.index:
            for pango_in_df_who in df_who_labels_available.loc[var, 'PangoRealNameSets']:
                if str_pango_real_name == pango_in_df_who:  # the lineage
                    return 'VOC or VOI'  # High risk (including VOC, VOI, VUM)
                elif str_pango_real_name.startswith(pango_in_df_who + '.'):  # sub-lineage
                    return 'VOC or VOI'
        return 'Low risk'


class HighRiskDetector:
    def __init__(self):
        # input
        self.df_who_labels = None
        self.dict_alias = None
        self.in_path = None
        self.current_date = None
        self.time_interval = None
        # calc
        self.mcan = None
        self.new_haps_in_network = None
        self.features = None
        self.labels = None
        self.classifier = None
        self.y_score = None
        self.y_pred = None
        self.type_classifier = None

    def set_current_date(self, date_str):
        self.current_date = Tools.str2date(date_str)

    def set_time_interval(self, days_int):
        self.time_interval = dt.timedelta(days=days_int)

    def generate_feature_label(self, feature_select=None, new_system=False):
        pango = self.new_haps_in_network.iloc[:, 0]
        label_class = Label()
        label_class.df_who_labels = self.df_who_labels
        label_class.dict_alias = self.dict_alias
        label_class.assign_labels(pango, new_system)
        rows = label_class.series_labels.notna()

        self.features = self.new_haps_in_network.iloc[:, 1:].loc[rows, :]
        self.labels = label_class.series_labels.loc[rows]

        if feature_select is not None:
            self.features = self.features[list(feature_select)]  # feature_select is a set of features' names

        return self.labels, self.features

    def generate_feature_label_pango(self, feature_select=None, new_system=False):
        pango = self.new_haps_in_network.iloc[:, 0]
        label_class = Label()
        label_class.df_who_labels = self.df_who_labels
        label_class.dict_alias = self.dict_alias
        label_class.assign_labels(pango, new_system=new_system)
        rows = label_class.series_labels.notna()

        self.features = self.new_haps_in_network.iloc[:, 1:].loc[rows, :]
        self.labels = label_class.series_labels.loc[rows]
        pango = pango.loc[rows]

        if feature_select is not None:
            self.features = self.features[list(feature_select)]  # feature_select is a set of features' names

        return self.labels, self.features, pango

    @staticmethod
    def hap_filter(df_haps):
        # return the growing haplotype
        rows = df_haps['ratio_of_new'] > 0
        columns = ['Pango', 'betweenness', 'out_degree',
                   'depth', 'size', 'GIE', 'ratio_of_new',
                   'number_of_mutations']
        return df_haps.loc[rows, columns]

    def drop_duplicates_feature_label(self):
        tmp_lf = pd.concat([self.labels, self.features], axis=1).drop_duplicates()
        self.labels = tmp_lf.iloc[:, 0]
        self.features = tmp_lf.iloc[:, 1:tmp_lf.shape[1]]
        del tmp_lf

    def read_exists_haps(self, single=False):
        return self.read_exists_haps_new(single=single)

    def read_exists_haps_new(self, single=False):
        # read previous McAN and features
        self.new_haps_in_network = pd.DataFrame()
        features = Features(out_path=self.in_path,
                            samples=None,
                            current_date=self.current_date,
                            time_interval=None)
        load_date = self.current_date
        while os.path.exists(features.full_path()):
            df = self.hap_filter(features.load())
            self.new_haps_in_network = \
                pd.concat([self.new_haps_in_network, df], axis=0, join='outer')
            if single:
                return None
            load_date -= self.time_interval
            features.__init__(out_path=self.in_path,
                              samples=None,
                              current_date=load_date,
                              time_interval=None)
        return self.new_haps_in_network

    def full_path_classifier(self, date=None) -> str:
        if date is None:
            date = self.current_date
        return f'{self.in_path}/{file_name_classifier(date, self.type_classifier)}.pkl'

    def train(self, feature_select=None, new_system=False):
        self.read_exists_haps()
        self.generate_feature_label(feature_select=feature_select, new_system=new_system)
        self.classifier = get_classifier(self.type_classifier)
        self.classifier.fit(np.array(self.features), np.array(self.labels))
        joblib.dump(self.classifier, self.full_path_classifier())

    def need_retain(self):
        series = self.df_who_labels['DesignDateAsVOCVOI']
        series = series[series <= self.current_date]
        series = series[series > self.current_date - self.time_interval]
        if len(series) >= 1:  # at lest one new VOC or VOI
            return True
        return False

    def full_path_y_score(self, date=None) -> str:
        if date is None:
            date = self.current_date
        return f'{self.in_path}/{file_name_y_score(date, self.type_classifier)}.npy'

    def full_path_y_pred(self, date=None) -> str:
        if date is None:
            date = self.current_date
        return f'{self.in_path}/{file_name_y_pred(date, self.type_classifier)}.pkl'

    def full_path_ground_truth(self, date=None) -> str:
        if date is None:
            date = self.current_date
        return f'{self.in_path}/{file_name_ground_truth(date)}.pkl'

    def full_path_pango(self, date=None) -> str:
        if date is None:
            date = self.current_date
        return f'{self.in_path}/{file_name_pango(date)}.pkl'

    def test(self, feature_select=None, new_system=False):
        """
        read the latest feature
        read the latest classifier
        calc y_score for the feature
        :return:
        """
        self.read_exists_haps_new(single=True)
        _, _, pango = self.generate_feature_label_pango(feature_select=feature_select, new_system=new_system)
        date = self.current_date - self.time_interval
        while not os.path.exists(self.full_path_classifier(date=date)):
            date -= self.time_interval
        self.classifier = joblib.load(self.full_path_classifier(date=date))
        self.y_score = self.classifier.predict_proba(np.array(self.features))
        self.y_pred = self.classifier.predict(np.array(self.features))

        np.save(self.full_path_y_score(), self.y_score)
        joblib.dump(self.y_pred, self.full_path_y_pred())
        joblib.dump(self.labels, self.full_path_ground_truth())
        joblib.dump(pango, self.full_path_pango())

    def get_classifier(self):
        date = self.current_date - self.time_interval
        while not os.path.exists(self.full_path_classifier(date=date)):
            date -= self.time_interval
        return joblib.load(self.full_path_classifier(date=date))

    def get_current_y_score(self):
        return np.load(self.full_path_y_score())

    def get_current_y_pred(self):
        return joblib.load(self.full_path_y_pred())

    def get_current_pango(self):
        return joblib.load(self.full_path_pango())

    def get_ground_truth(self):
        return joblib.load(self.full_path_ground_truth())


class PerformanceMetric:
    def __init__(self):
        # input
        self.start_date = None
        self.end_date = None
        self.time_interval = None
        self.type_classifier = None
        self.out_path = None
        self.df_who_labels = None
        self.dict_alias = None
        # intermediate
        self.current_date = None
        self.y_score = None
        self.y_pred = None
        self.mcan_feature = None
        self.ground_truth = None
        self.classifier = None
        self.pango = None
        # output
        self.performance_date = None
        self.detection_date_who_label = None

    def next(self):
        self.current_date += self.time_interval

    # bug BA* -> None, AY -> None

    #
    def pango2who_label(self, str_alias, sublineage=True, ignore_recombination=False):
        return Tools.pango2who_label(str_alias, self.dict_alias, self.df_who_labels,
                                     sublineage=sublineage, ignore_recombination=ignore_recombination)
        #real_name = Tools.pango_alias2real_name(self.dict_alias, str_alias)  # checked, good for BA*
        #if real_name is None:
        #    return None

        #for var in self.df_who_labels.index:
        #    for pango_in_df_who in self.df_who_labels.loc[var, 'PangoRealNameSets']:
        #        if real_name.startswith(pango_in_df_who):
        #            if len(pango_in_df_who) == len(real_name):
        #                return self.df_who_labels.loc[var, 'WHOLabel']
        #            elif real_name[len(pango_in_df_who)] == '.':
        #                return self.df_who_labels.loc[var, 'WHOLabel']
        #return None

    def display_roc(self):
        fig, ax = plt.subplots(figsize=(6, 6))
        RocCurveDisplay.from_predictions(np.array(self.ground_truth),
                                         self.y_score[:, 1],
                                         pos_label=self.classifier.classes_[1],
                                         ax=ax,
                                         name=f"{self.classifier.classes_[1]} as positive class")
        plt.plot([0, 1], [0, 1], "k--", label="chance level (AUC = 0.5)")
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.title(f"ROC curves on {self.current_date}")
        plt.legend()

    def set_time_interval(self, int_days):
        self.time_interval = dt.timedelta(days=int_days)

    def performance(self):
        self.current_date = self.start_date
        self.performance_date = pd.DataFrame()
        self.detection_date_who_label = pd.DataFrame()
        hrd = HighRiskDetector()
        roc_auc = []
        ap = []
        date = []
        f1 = []
        accuracy = []
        recall = []
        precision = []
        pango = pd.DataFrame()
        who_label = pd.DataFrame()
        while self.current_date <= self.end_date:
            hrd.__init__()
            hrd.current_date = self.current_date
            hrd.in_path = self.out_path
            hrd.type_classifier = self.type_classifier
            hrd.time_interval = self.time_interval

            self.y_score = hrd.get_current_y_score()
            self.classifier = hrd.get_classifier()
            self.ground_truth = hrd.get_ground_truth()
            self.y_pred = hrd.get_current_y_pred()
            self.pango = hrd.get_current_pango()

            # ROC figure
            self.display_roc()
            plt.savefig(self.path_roc())
            plt.close()

            pango_pred = self.pango[self.y_pred == 'VOC or VOI']
            # check the args of lambda function !!!
            who_label_pred = pango_pred.apply(
                lambda x: self.pango2who_label(x, sublineage=False, ignore_recombination=False)
            )
            # need to change manually
            # set sublineage = False or True for pango2who_label
            # defin the meaning of others (recombination?)
            # bug: above code. BA* -> None, AY-> None; (self.pango2who_label need fix)

            tmp_s = pd.DataFrame()
            tmp_s[self.current_date] = pango_pred.value_counts(dropna=False)
            pango = pd.concat([pango, tmp_s],
                              axis=1, join='outer', ignore_index=False)

            tmp_s = pd.DataFrame()
            tmp_s[self.current_date] = who_label_pred.value_counts(dropna=False)
            who_label = pd.concat([who_label, tmp_s],
                                  axis=1, join='outer', ignore_index=False)

            date.append(self.current_date)
            roc_auc.append(
                roc_auc_score(np.array(self.ground_truth), self.y_score[:, 1])
            )
            ap.append(
                average_precision_score(np.array(self.ground_truth),
                                        self.y_score[:, 1],
                                        # average='micro',
                                        pos_label=self.classifier.classes_[1])
            )
            accuracy.append(
                accuracy_score(np.array(self.ground_truth), self.y_pred, normalize=True)
            )
            f1.append(
                f1_score(np.array(self.ground_truth), self.y_pred, pos_label=self.classifier.classes_[1])
            )
            recall.append(
                recall_score(np.array(self.ground_truth), self.y_pred, pos_label=self.classifier.classes_[1])
            )
            precision.append(
                precision_score(np.array(self.ground_truth), self.y_pred, pos_label=self.classifier.classes_[1])
            )
            self.next()
        self.performance_date['date'] = date
        self.performance_date['ap'] = ap
        self.performance_date['roc_auc'] = roc_auc
        self.performance_date['f1'] = f1
        self.performance_date['accuracy'] = accuracy
        self.performance_date['recall'] = recall
        self.performance_date['precision'] = precision
        joblib.dump(self.performance_date, f'{self.out_path}/performance_date_{self.type_classifier}.pkl')
        joblib.dump(pango, f'{self.out_path}/pango_date_{self.type_classifier}.pkl')
        joblib.dump(who_label, f'{self.out_path}/who_label_date_{self.type_classifier}.pkl')
        pango_earliest = pd.Series()
        for i in pango.index:
            for j in pango.columns:
                if pango.loc[i, j] >= 1:
                    pango_earliest[i] = j
                    break
        print(pango_earliest)
        joblib.dump(pango_earliest, f'{self.out_path}/pango_earliest_{self.type_classifier}.pkl')

        who_label_earliest = pd.Series()
        for i in who_label.index:
            for j in who_label.columns:
                if who_label.loc[i, j] >= 1:
                    who_label_earliest[i] = j
                    break
        print(who_label_earliest)
        joblib.dump(who_label_earliest, f'{self.out_path}/who_label_earliest_{self.type_classifier}.pkl')

    def path_roc(self):
        return f"{self.out_path}/ROC_{self.type_classifier}_{self.current_date}.pdf"


if __name__ == "__main__":
    path_samples_test = "/media/lun/Black_5TB_SG/code/predict_general/data" \
                        "/Acc_cDate_sDate_Country_Pango_WHOLabel_MutHiFreq"
    df_sample = Tools.read_samples(path_samples_test, n_rows=100)
    features1 = Features(out_path='/media/lun/Black_5TB_SG/code/predict_general/rlt',
                         samples=df_sample,
                         current_date=max(df_sample['sDate']),
                         time_interval=dt.timedelta(days=7))
    features1.feature_pango_mcan(num_of_processes=3)

    '''
    hrp = HighRiskDetector()
    hrp.in_path = '/media/lun/Black_5TB_SG/code/predict_general/rlt'
    hrp.set_current_date('2020-10-30')
    hrp.set_time_interval(7)
    hrp.read_exists_haps()
    y, X = hrp.generate_feature_label()
    '''
