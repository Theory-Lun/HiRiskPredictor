import pandas as pd
import HighRiskDetector
import Tools
import Simulator
import argparse
import joblib
import numpy as np


def sampling(path_samples: str, ratio: float, start_date, end_date, output, reference=None):
    """

    :param path_samples:
    :param ratio: a number between 0 and 1
    :param start_date: YYYY-MM-DD, filter before sampling
    :param end_date: YYYY-MM-DD, filter before sampling
    :param output: the fill output filename
    :param reference: the accession number of reference. keep this before sampling.
    :return: None
    """

    df_sample = Tools.read_samples(path_samples, new=True)
    start_date_dt = Tools.str2date(start_date)
    end_date_dt = Tools.str2date(end_date)
    df_reference = pd.DataFrame()
    if reference is not None:
        df_reference = df_sample[df_sample.index == reference]
        df_sample.drop([reference], inplace=True)
    df_sample = df_sample[df_sample['sDate'] >= start_date_dt]
    df_sample = df_sample[df_sample['sDate'] <= end_date_dt]
    df_sample = df_sample.sample(frac=ratio, random_state=1)
    if reference is not None:
        if df_reference.shape[0] >= 1:
            df_sample = pd.concat([df_sample, df_reference])
    # save!!!!!
    df_sample.to_csv(
        output, index=True, index_label='Accession ID', sep='\t',
        header=['Lineage', 'Location', 'Submission Date', 'Mutations'],
        columns=['Pango', 'Country', 'sDate_str', 'Mutations_str'],
        date_format="%Y-%m-%d"
    )


def calc_features_surveillance(path_samples: str, path_alias: str, path_who_labels: str,
                               output_path: str, start_date: str, end_date: str,
                               time_interval_int: int, num_of_processes: int,
                               n_rows) -> None:
    # read data (do not need alias' file and WHO labels file)
    df_sample = Tools.read_samples(path_samples, n_rows=n_rows, new=True)
    dict_alias = Tools.read_alias(path_alias)
    df_who_labels = Tools.read_who_labels(path_who_labels, dict_alias)

    # class init
    simulator = Simulator.Simulator()
    simulator.samples = df_sample
    simulator.df_who_labels = df_who_labels
    simulator.dict_alias = dict_alias
    simulator.set_time_interval(time_interval_int)
    simulator.start_date = simulator.str_to_date(start_date)
    simulator.end_date = simulator.str_to_date(end_date)

    tt = Tools.TicToc()
    # simulate started
    file = open(f'{output_path}/log.txt', mode="w")
    simulator.current_date = simulator.start_date
    features = HighRiskDetector.Features()
    while simulator.current_date <= simulator.end_date:
        print(f'{simulator.current_date} started ...')
        simulator.update_data_available()
        tt.tic()
        # construct hapnet and calculate features
        features.__init__(out_path=output_path,
                          samples=simulator.samples_available,
                          current_date=simulator.current_date,
                          time_interval=simulator.time_interval)
        features.feature_pango_mcan(num_of_processes=num_of_processes)
        print('%s, %.2f s' % (simulator.current_date, tt.toc()), file=file)
        simulator.next_date()
    del features
    file.close()


def predict_surveillance(path_alias, path_who_labels, output_path,
                         time_interval_int, start_date, end_date,
                         path_selected, new_system=False):
    dict_alias = Tools.read_alias(path_alias)
    df_who_labels = Tools.read_who_labels(path_who_labels, dict_alias)
    selected = joblib.load(path_selected)

    # class init
    simulator = Simulator.Simulator()
    # simulator.samples = df_sample
    simulator.df_who_labels = df_who_labels
    simulator.dict_alias = dict_alias
    simulator.set_time_interval(time_interval_int)
    simulator.start_date = simulator.str_to_date(start_date)
    simulator.end_date = simulator.str_to_date(end_date)

    tt = Tools.TicToc()
    # simulate started

    simulator.current_date = simulator.start_date
    while simulator.current_date <= simulator.end_date:
        print(f'{simulator.current_date} started ...')
        simulator.update_data_available()
        tt.tic()

        hrp = HighRiskDetector.HighRiskDetector()
        hrp.current_date = simulator.current_date
        hrp.time_interval = simulator.time_interval
        hrp.type_classifier = selected['type_classifier']
        hrp.df_who_labels = simulator.df_who_labels_available
        hrp.dict_alias = simulator.dict_alias
        hrp.in_path = output_path
        # test
        if simulator.have_classifier:
            hrp.df_who_labels = simulator.df_who_labels
            hrp.test(feature_select=selected['fea'], new_system=new_system)
            hrp.df_who_labels = simulator.df_who_labels_available
        # train
        if hrp.need_retain():
            print("need re-train")
            # updated for WHO's new system
            hrp.train(feature_select=selected['fea'], new_system=new_system)
            simulator.have_classifier = True
        else:
            print("do not need re-train")

        print(f'{simulator.current_date}, {tt.toc()} s')
        simulator.next_date()


def predict_surveillance_retrainfree(path_alias, path_who_labels, output_path,
                                     time_interval_int, start_date, end_date,
                                     path_selected, new_system=False):
    dict_alias = Tools.read_alias(path_alias)
    df_who_labels = Tools.read_who_labels(path_who_labels, dict_alias)
    selected = joblib.load(path_selected)

    # class init
    simulator = Simulator.Simulator()
    # simulator.samples = df_sample
    simulator.df_who_labels = df_who_labels
    simulator.dict_alias = dict_alias
    simulator.set_time_interval(time_interval_int)
    simulator.start_date = simulator.str_to_date(start_date)
    simulator.end_date = simulator.str_to_date(end_date)

    tt = Tools.TicToc()
    # simulate started

    simulator.current_date = simulator.start_date
    while simulator.current_date <= simulator.end_date:
        print(f'{simulator.current_date} started ...')
        simulator.update_data_available()
        tt.tic()

        hrp = HighRiskDetector.HighRiskDetector()
        hrp.current_date = simulator.current_date
        hrp.time_interval = simulator.time_interval
        hrp.type_classifier = selected['type_classifier']
        hrp.df_who_labels = simulator.df_who_labels_available
        hrp.dict_alias = simulator.dict_alias
        hrp.in_path = output_path
        # test
        hrp.df_who_labels = simulator.df_who_labels
        hrp.test(feature_select=selected['fea'], new_system=new_system)
        hrp.df_who_labels = simulator.df_who_labels_available

        print(f'{simulator.current_date}, {tt.toc()} s')
        simulator.next_date()


def performance_surveillance(path_alias, path_who_labels, output_path, time_interval_int,
                             start_date, end_date, path_selected):
    dict_alias = Tools.read_alias(path_alias)
    df_who_labels = Tools.read_who_labels(path_who_labels, dict_alias)
    selected = joblib.load(path_selected)

    pm = HighRiskDetector.PerformanceMetric()
    pm.start_date = Simulator.Simulator.str_to_date(start_date)
    pm.end_date = Simulator.Simulator.str_to_date(end_date)
    pm.set_time_interval(time_interval_int)
    pm.type_classifier = selected['type_classifier']
    pm.out_path = output_path
    pm.df_who_labels = df_who_labels
    pm.dict_alias = dict_alias

    pm.performance()


def my_parser():
    parser = argparse.ArgumentParser()
    # type of task
    parser.add_argument("--calc_features", action='store_true')
    parser.add_argument("--predict_surveillance", action='store_true')
    parser.add_argument("--performance_surveillance", action='store_true')
    parser.add_argument("--predict_surveillance_retrainfree", action='store_true')
    parser.add_argument("--sampling", action='store_true')
    # args
    # just for predict_surveillance
    parser.add_argument(
        "--new_system", action='store_true',
        help="Label assignment mode. Based on WHO's new variant system."
    )

    parser.add_argument("--samples", type=str)
    parser.add_argument("--alias", type=str)
    parser.add_argument("--wholabels", type=str)
    parser.add_argument("--output", type=str)
    parser.add_argument("--interval_days", type=int)
    parser.add_argument("--start_date", type=str)
    parser.add_argument("--end_date", type=str)
    parser.add_argument("--nprocesses", type=int)
    parser.add_argument("--nrows", type=int, default=None)
    parser.add_argument("--selected_feature_ml", type=str)
    parser.add_argument("--ratio", type=float)
    parser.add_argument("--reference", type=str, default=None)
    # return args
    return parser.parse_args()


def detector():
    args = my_parser()
    if args.sampling:
        sampling(
            path_samples=args.samples,
            ratio=args.ratio,
            start_date=args.start_date,
            end_date=args.end_date,
            reference=args.reference,
            output=args.output
        )
    if args.calc_features:
        calc_features_surveillance(path_samples=args.samples,
                                   path_alias=args.alias,
                                   path_who_labels=args.wholabels,
                                   output_path=args.output,
                                   start_date=args.start_date,
                                   end_date=args.end_date,
                                   time_interval_int=args.interval_days,
                                   num_of_processes=args.nprocesses,
                                   n_rows=args.nrows)

    if args.predict_surveillance:
        predict_surveillance(path_alias=args.alias,
                             path_who_labels=args.wholabels,
                             output_path=args.output,
                             time_interval_int=args.interval_days,
                             start_date=args.start_date,
                             end_date=args.end_date,
                             path_selected=args.selected_feature_ml,
                             new_system=args.new_system)

    if args.performance_surveillance:
        performance_surveillance(path_alias=args.alias,
                                 path_who_labels=args.wholabels,
                                 output_path=args.output,
                                 time_interval_int=args.interval_days,
                                 start_date=args.start_date,
                                 end_date=args.end_date,
                                 path_selected=args.selected_feature_ml)

    if args.predict_surveillance_retrainfree:
        predict_surveillance_retrainfree(path_alias=args.alias,
                                         path_who_labels=args.wholabels,
                                         output_path=args.output,
                                         time_interval_int=args.interval_days,
                                         start_date=args.start_date,
                                         end_date=args.end_date,
                                         path_selected=args.selected_feature_ml,
                                         new_system=args.new_system)


if __name__ == "__main__":
    detector()

'''
--calc_features
--samples
/home/lun/Study/HighRiskDetector/code/predict_general/data/Acc_cDate_sDate_Country_Pango_WHOLabel_MutHiFreq
--alias
/home/lun/Study/HighRiskDetector/code/predict_general/data/alias_key.json
--wholabels
/home/lun/Study/HighRiskDetector/code/predict_general/data/WHOLabels.tsv
--output
/home/lun/Study/HighRiskDetector/code/predict_general/rlt
--interval_days
7
--start_date
2020-10-09
--end_date
2020-12-11
--nprocesses
7
--nrows
7260433
'''

'''
--predict_surveillance \
--alias /home/lun/Study/HighRiskDetector/code/predict_general/data/alias_key.json \
--wholabels /home/lun/Study/HighRiskDetector/code/predict_general/data/WHOLabels.tsv \
--output /home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619 \
--interval_days 7 \
--start_date 2020-10-09 \
--end_date 2022-02-25 \
--selected_feature_ml /home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619_2/selected.pkl
'''

'''
--performance_surveillance \
--alias /home/lun/Study/HighRiskDetector/code/predict_general/data/alias_key.json \
--wholabels /home/lun/Study/HighRiskDetector/code/predict_general/data/WHOLabels.tsv \
--output /home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619 \
--interval_days 7 \
--start_date 2020-12-25 \
--end_date 2022-02-25 \
--selected_feature_ml /home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619_2/selected.pkl
'''
