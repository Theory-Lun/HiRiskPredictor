import datetime as dt
import Tools


class Simulator:
    def __init__(self):
        # all data constant
        self.samples = None
        self.df_who_labels = None
        self.dict_alias = None
        # date constant
        self.time_interval = None
        self.start_date = None
        self.end_date = None
        # current date
        self.current_date = None
        # available data
        self.samples_available = None
        self.df_who_labels_available = None
        # flag
        self.have_classifier = False

    def next_date(self):
        self.current_date += self.time_interval

    def previous_date(self):
        self.current_date -= self.time_interval

    def update_data_available(self):
        # do not support samples from Tools.read_samples_mcan
        if self.samples is not None:
            self.samples_available = \
                self.samples.loc[self.samples['sDate'] <= self.current_date, :]
        if self.df_who_labels is not None:
            self.df_who_labels_available = \
                self.df_who_labels.loc[self.df_who_labels['DesignDateAsVOCVOI'] <= self.current_date, :]

    def set_time_interval(self, int_days):
        self.time_interval = dt.timedelta(days=int_days)

    @staticmethod
    def str_to_date(str_date):
        return Tools.str2date(str_date)


if __name__ == "__main__":
    path = "/home/lun/Study/HighRiskDetector/code/predict_general"

    path_samples_test = path + "/data/Acc_cDate_sDate_Country_Pango_WHOLabel_MutHiFreq"
    path_alias_test = path + "/data/alias_key.json"
    path_who_labels_test = path + "/data/WHOLabels.tsv"
    output_path = path + '/rlt'
    time_interval_int = 7
    num_of_processes = 7

    df_sample = Tools.read_samples(path_samples_test, n_rows=100000)
    dict_alias = Tools.read_alias(path_alias_test)
    df_who_labels = Tools.read_who_labels(path_who_labels_test, dict_alias)

    # class init
    simulator = Simulator()
    simulator.samples = df_sample
    simulator.df_who_labels = df_who_labels
    simulator.dict_alias = dict_alias
    simulator.set_time_interval(time_interval_int)
    simulator.start_date = min(df_who_labels['DesignDateAsVOCVOI']) - 10 * simulator.time_interval
    simulator.end_date = max(df_sample['sDate'])

    tt = Tools.TicToc()
    # simulate started
    import HighRiskDetector

    simulator.current_date = simulator.start_date
    features = HighRiskDetector.Features()
    while simulator.current_date <= simulator.end_date:
        print(f'{simulator.current_date} started ...')
        simulator.update_data_available()
        tt.tic()
        # construct hapnet and calculate features
        features.__init__(out_path=output_path,
                          samples=simulator.samples_available,
                          current_date=simulator.current_date,
                          time_interval=simulator.time_interval)
        features.feature_pango_mcan(num_of_processes=num_of_processes)
        '''
        do some thing
        '''
        print(f'{simulator.current_date}, {tt.toc()} s')
        simulator.next_date()
    del features
