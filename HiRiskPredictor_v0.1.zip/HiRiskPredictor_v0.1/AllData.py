import HighRiskDetector
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
import lightgbm
from sklearn.linear_model import LogisticRegression
import Tools
import datetime as dt
from itertools import combinations
import pandas as pd
import numpy as np
from sklearn.metrics import RocCurveDisplay, roc_auc_score, average_precision_score, \
    accuracy_score, f1_score, recall_score, PrecisionRecallDisplay, precision_score
import matplotlib.pyplot as plt
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC


def display_roc(y_score, ground_truth, classifier):
    fig, ax = plt.subplots(figsize=(6, 6))
    RocCurveDisplay.from_predictions(np.array(ground_truth),
                                     y_score[:, 1],
                                     pos_label=classifier.classes_[1],
                                     ax=ax,
                                     name=f"{classifier.classes_[1]} as positive class")
    plt.plot([0, 1], [0, 1], "k--", label="chance level (AUC = 0.5)")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(f"ROC curves")
    plt.legend()


def display_pr(y_score, ground_truth, classifier):
    fig, ax = plt.subplots(figsize=(6, 6))
    PrecisionRecallDisplay.from_predictions(np.array(ground_truth),
                                            y_score[:, 1],
                                            pos_label=classifier.classes_[1],
                                            ax=ax,
                                            name=f"{classifier.classes_[1]} as positive class")
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title(f"PR curves")
    plt.legend()


def get_type_classifier():
    return ['lr', 'lgbm', 'rf']
    # return ['lr', 'lgbm', 'rf', 'svm']


def get_classifier(type_classifier):
    if type_classifier == 'lr':
        classifier = LogisticRegression(solver='lbfgs', class_weight='balanced', max_iter=1000, random_state=42)
    elif type_classifier == 'lgbm':
        classifier = lightgbm.LGBMClassifier(class_weight='balanced', random_state=42)
    elif type_classifier == 'rf':
        classifier = RandomForestClassifier(class_weight='balanced', random_state=42)
    #elif type_classifier == 'svm':
    #    classifier = SVC(class_weight='balanced', random_state=42, tol=0.001)
    else:
        classifier = None
    return classifier


def all_data(path_alias, path_who_labels, in_path, out_path, current_date, time_interval, n_jobs, n_splits):
    # read all haps
    hrd = HighRiskDetector.HighRiskDetector()
    hrd.in_path = in_path
    hrd.current_date = Tools.str2date(current_date)
    hrd.time_interval = dt.timedelta(days=time_interval)
    hrd.dict_alias = Tools.read_alias(path_alias)
    hrd.df_who_labels = Tools.read_who_labels(path_who_labels, hrd.dict_alias)
    hrd.read_exists_haps()
    # assign label
    hrd.generate_feature_label()
    # remove repeat samples
    hrd.drop_duplicates_feature_label()
    # split train and test
    x_train, x_test, y_train, y_test = train_test_split(
        hrd.features, hrd.labels, test_size=0.2, random_state=42)
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    type_classifier = []
    mean = []
    std = []
    fea = []
    # performance on training data, k-fold cv
    # each combination of features
    for r in range(1, x_train.shape[1] + 1):
        for feature_comb in combinations(x_train.columns, r):
            x_train_fea = x_train[list(feature_comb)]
            # k-fold cv
            for current_type_classifier in get_type_classifier():
                classifier = get_classifier(current_type_classifier)
                scores = cross_val_score(classifier, x_train_fea, y_train, cv=cv, n_jobs=n_jobs)
                # record
                type_classifier.append(current_type_classifier)
                mean.append(scores.mean())
                std.append(scores.std())
                fea.append(feature_comb)
                # print
                print(current_type_classifier)
                print(scores.mean())
                print(scores.std())
                print(feature_comb)
    performance = pd.DataFrame()
    performance['type_classifier'] = type_classifier
    performance['mean'] = mean
    performance['std'] = std
    performance['fea'] = fea
    # select
    max_value_index = performance['mean'].idxmax()
    max_row = performance.iloc[max_value_index, :]
    # performance on test data
    classifier = get_classifier(max_row['type_classifier'])
    x_train_fea = x_train[list(max_row['fea'])]
    classifier.fit(x_train_fea, y_train)
    x_test_fea = x_test[list(max_row['fea'])]
    y_score = classifier.predict_proba(x_test_fea)
    y_pred = classifier.predict(x_test_fea)

    roc_auc = roc_auc_score(np.array(y_test), y_score[:, 1])
    ap = average_precision_score(np.array(y_test),
                                 y_score[:, 1],
                                 pos_label=classifier.classes_[1])
    f1 = f1_score(np.array(y_test), y_pred, pos_label=classifier.classes_[1])
    accuracy = accuracy_score(np.array(y_test), y_pred, normalize=True)
    recall = recall_score(np.array(y_test), y_pred, pos_label=classifier.classes_[1])
    precision = precision_score(np.array(y_test), y_pred, pos_label=classifier.classes_[1])

    # save
    performance_on_test = {
        'roc_auc': roc_auc,
        'ap': ap,
        'f1': f1,
        'accuracy': accuracy,
        'recall': recall,
        'precision': precision
    }
    joblib.dump(performance, f'{out_path}/performance_kfold_cv.pkl')
    joblib.dump(max_row, f'{out_path}/selected.pkl')
    joblib.dump(performance_on_test, f'{out_path}/performance_on_test.pkl')
    joblib.dump(classifier, f'{out_path}/classifier.pkl')

    # draw
    display_roc(y_score, y_test, classifier)
    plt.savefig(f'{out_path}/roc_test.pdf')
    plt.close()

    display_pr(y_score, y_test, classifier)
    plt.savefig(f'{out_path}/pr_test.pdf')
    plt.close()


if __name__ == "__main__":
    all_data(
        path_alias='/home/lun/Study/DataCleaning_SARS-CoV-2/data/2023_07_28/alias_key.json',
        path_who_labels='/home/lun/Study/DataCleaning_SARS-CoV-2/data/2023_07_28/WHOLabels.tsv',
        in_path='/home/lun/Study/DataCleaning_SARS-CoV-2/rlt',
        out_path='/home/lun/Study/DataCleaning_SARS-CoV-2/rlt_2',
        current_date='2022-02-26',  # '2022-02-26' '2021-02-06'
        time_interval=7,
        n_jobs=1,
        n_splits=5)

    #all_data(
    #    path_alias='/home/lun/Study/HighRiskDetector/code/predict_general/data/alias_key.json',
    #    path_who_labels='/home/lun/Study/HighRiskDetector/code/predict_general/data/WHOLabels.tsv',
    #    in_path='/home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619',
    #    out_path='/home/lun/Study/HighRiskDetector/code/predict_general/rlt_20230619_2',
    #    current_date='2022-02-25',  # '2022-02-25' '2021-01-22'
    #    time_interval=7,
    #    n_jobs=1,
    #    n_splits=5)
